
# Sanbrary 

Is a digital management library based on web in my school San means Santana wich is nick name of my school and brary mean library.


there are 4 different file extention. 1) .html 2) .db 3) .py 4).css.

## html 
there are 6 different html that represent 6 different pages. books, borrow, review, layout, login, index.
index will appear firts,
borrow, review, books needed to login firts.
i use layout to keep the nav bar and then extend to the other pages.

## .db
sanbrary.db is the database there are 4 different table there 
1.books 2.reviews 3.borrow 4. users.

books reviews and borrow are interconnected with teh foreign key is book_id. 

## .py
app.py is the main code (beckend)
there are flash in evry function that allert user he success make action or not .
there are also a lot of db.execute that giving me flexibility to manage database (Add, delete, search)

## .css
this web app using bootstrap and also my own css for the customize. it allow the progrm to have a good look

