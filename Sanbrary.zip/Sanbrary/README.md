
# Sanbrary 

Is a digital management library based on web in my school San means Santana wich is nick name of my school and brary mean library.
see on youtube : https://youtu.be/HXF8P8-2hpQ

this web use for student and admin (library staf)

for admin they should have to login 

(username: admin password: 1111), student don not need to login

## in the admin side 
you will see Home, book, reviews, borrow book
Home: you can search a book by title, author, year, book id, and status. this will give top 5 book. And also under the search book there are the newest 7 book taht has been added

book: you can add book by fill all the form there, there will sign that a new book has been added or not. you can also delete a book

reviews on the reviews you can add or delete some review that may be your studet said to you or write on some papper.

borrow book : you can add a book to borrow by some student and trace the date student borrow, and the status of the book will change from ready to borrow, to give you sign that the book was borrow by someone.

logout: to keep the data save where you not in your computer.

## student side
you can looking for top 7 newest of the book and you can search a book on the library and then grab the book in the place by book ID that can contain the book potition.


## FAQ

#### 1. what is username and password for admin

username : admin password: 1111

#### 2. why student do not need to login

Because its just for library staff, that can manage their book. In further may be i should add its

