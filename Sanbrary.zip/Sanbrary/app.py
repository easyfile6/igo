import datetime
from cs50 import SQL
from flask import Flask, render_template, request, flash, redirect, session
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

#config SQL lib
db = SQL("sqlite:///sanbrary.db")

#home
@app.route("/", methods = ["GET", "POST"])
def home():
    #access from post method
    if request.method == "POST":
        #show 7 newwest books
        books = db.execute("SELECT * FROM books JOIN reviews ON books.book_id = reviews.book_id ORDER BY books.time DESC LIMIT 7")
        # get the type on form
        look = request.form.get("search")
        #chech if search nt blank
        if not look:
            # tell the warning
            flash("Type something to search", "danger")
            # back to index.html
            return render_template("index.html", books=books)
        else:
        # search the book by its title, its author, it'a year, its status and order descending by the time and limit book by 5
            # define search because we can put ? beetwen '' on db.excecute
            search = '%'+look+'%'
            book = db.execute("SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR year LIKE ? OR book_id LIKE ? OR status LIKE ? ORDER BY time DESC LIMIT 5", search, search, search, search, search)
            if not book:
                # tell the warning
                flash("There is no such book", "warning")
                # back to index.html
                return render_template("index.html", books=books)
            # back to index.html with the result of search
            return render_template("index.html", books=books, book=book)
    else:
        # go to index.html
        books = db.execute("SELECT * FROM books JOIN reviews ON books.book_id = reviews.book_id ORDER BY books.time DESC LIMIT 7")
        return render_template("index.html", books=books)

# login
@app.route("/login", methods = ["GET", "POST"])
def login():
    # forget any user_id
    session.clear()

    # access from post method
    if request.method == "POST":
        #make sure username and password exist
        if not request.form.get("username") or not request.form.get("password"):
            #tell the warning
            flash("Provide username and password", "danger")
            #back to login
            return render_template("login.html")
        #query database for username
        rows = db.execute("SELECT * FROM users WHERE username = ?", request.form.get("username"))
        #make sure user and pass are match
        if len(rows) != 1 or not check_password_hash(rows[0]["password"], request.form.get("password")):
            #tell the warning
            flash("username and password incorrect", "danger")
            #back to login
            return render_template("login.html")
        #remember user
        session["user_id"] = rows[0]["id"]

        #redirect user to home
        return redirect("/")

    else:
        #go to login
        return render_template("login.html")

# Logout
@app.route("/logout")
def logout():
    #end session acces from get method by default
    session.clear()
    #back to home
    return redirect("/")

#books
@app.route("/books", methods = ["GET", "POST"])
def book():
    #access from post method
    if request.method == "POST":
        #get value from the form
        title = request.form.get("title")
        author = request.form.get("author")
        year = request.form.get("year")
        book_id = request.form.get("book_id")
        #get the time right now
        time = datetime.datetime.now()
        #check is form not blank
        if not title or not author or not year or not book_id:
            # tell the warning
            flash("Provide title, author, year, and book_id", "danger")
            # query the book to show on table
            books = db.execute("SELECT * FROM books")
            # bak to book.html
            return render_template("books.html", books=books)
        #check is title already exist?
        if title in db.execute("SELECT title FROM books"):
            # tell the warning
            flash("The title of book has already exist!", "danger")
            # query the book to show on table
            books = db.execute("SELECT * FROM books")
            # back to the book.html
            return render_template("books.html", books=books)
        #insert new books
        db.execute("INSERT INTO books (title, author, year, book_id, time) VALUES(?, ?, ?, ?, ?)", title, author, year, book_id, time)
        # tell that succes input
        flash("A new Book has been added", "success")
        #query to show books
        books = db.execute("SELECT * FROM books")
        # back to book.html
        return render_template("books.html", books=books)
    else:
        #query to show books
        books = db.execute("SELECT * FROM books")
        # go to html.code
        return render_template("books.html", books=books)

# book delete
@app.route("/delbook/<id>", methods=["POST"])
def delete_book(id):
    #delete the book by id
    db.execute("DELETE FROM books WHERE id = ?", id)
    #show books
    books = db.execute("SELECT * FROM books")
    return render_template("books.html", books=books)

#borrow
@app.route("/borrow", methods = ["GET", "POST"])
def borrow():
    if request.method == "POST":
        #get form from borrow page
        name = request.form.get("name")
        kelas = request.form.get("class")
        book_id = request.form.get("book_id")
        date = request.form.get("date")
        # query the book by book id
        books_id = db.execute("SELECT * FROM books WHERE book_id = ?", book_id)
        #query the status by book id
        status = db.execute("SELECT status FROM books WHERE book_id =? AND status = 'borrowed'", book_id)
        #check is form not blank
        if not name or not kelas or not book_id or not date:
            # tell the warning because is blank
            flash("Provide name, class, book_id, and date", "danger")
            borrows = db.execute("SELECT * FROM borrow JOIN books ON borrow.book_id=books.book_id")
            return render_template("borrow.html", borrows=borrows)
        #check if book id already exist
        elif not books_id:
            flash("Nothing match with Book ID", "danger")
            borrows = db.execute("SELECT * FROM borrow JOIN books ON borrow.book_id=books.book_id")
            return render_template("borrow.html", borrows=borrows)
        #check if the book ready or borrowe by some one else
        elif status:
            flash("The book has already borrowed by other student", "danger")
            borrows = db.execute("SELECT * FROM borrow JOIN books ON borrow.book_id=books.book_id")
            return render_template("borrow.html", borrows=borrows)
        #order borrow the book
        else:
            db.execute("UPDATE books SET status = 'borrowed' WHERE book_id  =?", book_id)
            db.execute("INSERT INTO borrow(name, kelas, date, book_id) VALUES(?, ?, ?, ?)", name, kelas, date, book_id)
            flash("A new data has been added", "success")
            borrows = db.execute("SELECT * FROM borrow JOIN books ON borrow.book_id=books.book_id")
            return render_template("borrow.html", borrows=borrows)
    else:
        #show the borrowed book
        borrows = db.execute("SELECT * FROM borrow JOIN books ON borrow.book_id=books.book_id")
        return render_template("borrow.html", borrows=borrows)
# borrow delete
@app.route("/bordel/<book_id>", methods=["POST"])
def delete_borrow(book_id):
    #change the status
    db.execute("UPDATE books SET status = 'ready' WHERE book_id =?", book_id)
    # delet book
    db.execute("DELETE FROM borrow WHERE book_id = ?", book_id)
    #show borrow book
    borrows = db.execute("SELECT * FROM borrow JOIN books ON borrow.book_id=books.book_id")
    return render_template("borrow.html", borrows=borrows)


#review
@app.route("/review", methods = ["GET", "POST"])
def review():
    if request.method == "POST":
        # form
        name = request.form.get("name")
        book_id = request.form.get("book_id")
        date = request.form.get("date")
        review = request.form.get("review")
        # check if the book id exist
        books_id = db.execute("SELECT * FROM books WHERE book_id = ?", book_id)
        if not books_id:
            flash("Nothing match with Book ID", "danger")
            reviews = db.execute ("SELECT * FROM reviews JOIN books ON reviews.book_id = books.book_id")
            return render_template("review.html", reviews=reviews)
        # add review
        db.execute("INSERT INTO reviews (name, book_id, date, review) VALUES(?, ?, ?, ?)", name, book_id, date, review)
        flash("A new review has been added", "success")
        reviews = db.execute ("SELECT * FROM reviews JOIN books ON reviews.book_id = books.book_id")
        return render_template("review.html", reviews=reviews)
    else:
        # show the review
        reviews = db.execute ("SELECT * FROM reviews JOIN books ON reviews.book_id = books.book_id")
        return render_template("review.html", reviews=reviews)

# del review
@app.route("/revdel/<book_id>", methods=["POST"])
def delete_review(book_id):
    # delet review
    db.execute("DELETE FROM reviews WHERE book_id = ?", book_id)
    #show review
    reviews = db.execute ("SELECT * FROM reviews JOIN books ON reviews.book_id = books.book_id")
    return render_template("review.html", reviews=reviews)